import tkinter as tk
import math
import matplotlib.pyplot as plt


def fun(xx):
    return math.exp(xx)*math.sin(xx)**2


x = [(i/5)*math.pi for i in range(6)]

y = [fun(xx) for xx in x]

def Gauss(a, y):
    cnt = len(a)
    x = [0 for i in range(cnt)]
    for i in range(0, cnt-1):
        for j in range(i+1, cnt):
            m = a[j][i]/a[i][i]
            y[j] -= y[i]*m
            for k in range(i, cnt):
                a[j][k] -= m*a[i][k]
    for i in range(0, cnt-1):
        for j in range(i+1, cnt):
            m = a[cnt-1-j][cnt-1-i]/a[cnt-1-i][cnt-1-i]
            y[cnt-1-j] -= m*y[cnt-1-i]
            a[cnt-1-j][cnt-1-i] = 0
    for i in range(0, cnt):
        x[i] = y[cnt-1-i]/a[cnt-1-i][cnt-1-i]
    return x

def MNK(x, y, n):
    cnt = len(x)
    x_s = [0 for i in range(2*n+1)]
    y_s = [0 for i in range(n+1)]
    for i in range(2*n+1):
        for j in range(cnt):
            x_s[i] += x[j]**i
    for i in range(n+1):
        for j in range(cnt):
            y_s[i] += y[j]*x[i]**i
    a = [[0 for i in range(n+1)] for j in range(n+1)]
    for i in range(n+1):
        for j in range(n+1):
            a[i][j] = x_s[i+j]
    return Gauss(a, y_s)

print(MNK(x, y, 3))

