import sys
import random
import pyautogui
import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
from tkinter import font
from PIL import Image, ImageTk
import pygame
import pyglet, os


class Minesweeper(tk.Tk):
    def __init__(self):
        super().__init__()
        self.back_pic = [Image.open(f"Img//Img//num{x}.png") for x in range(24)]
        self.pictures = [ImageTk.PhotoImage(self.back_pic[x]) for x in range(24)]

        self.m = 10
        self.n = 10
        pygame.mixer.init()
        pygame.mixer.music.load("Dev.mp3")
        pygame.mixer.music.play(-1)
          # Image.open(f"Img//number_{x}.png")
        pyglet.font.add_file('Abaddon Cyr.ttf')
        self.cells = 100
        self.exploring = [[-2 for x in range(self.n)] for y in range(self.m)]
        self.flags = 10
        self.ground = [[-2 for x in range(self.n)] for y in range(self.m)]
        self.field = []
        self.game_win = tk.Toplevel(self, bg="#622", borderwidth=4, relief="ridge")
        self.game_win.withdraw()
        self.game_win.overrideredirect(True)
        self.saves_win = tk.Toplevel(self, bg="#622", borderwidth=3, relief="ridge")
        self.saves_win.withdraw()
        self.saves_win.overrideredirect(True)

        self.config(bg="#77FFDD", borderwidth=-2)
        self.wm_attributes("-transparentcolor", "#77FFDD")

        self.geometry("+750+130")
        self.overrideredirect(True)

        img_win = tk.Canvas(self, borderwidth=-2, width=510, height=652)
        img_win.pack(expand=1)
        img_win.create_image(0, 0, anchor="nw", image=self.pictures[12])
        self.win_moving(self, img_win)

        self.button_new = tk.Button(img_win, width=14, height=2, bg="#311", activebackground="#844", text="Новая игра",
                                    font=("Abaddon Cyr", 18), command=self.game_mode, foreground="#F00")
        self.button_selection(self.button_new)
        self.button_new.place(x=145, y=150)
        self.button_load = tk.Button(img_win, width=14, height=2, bg="#311", activebackground="#844",
                                     text="Загузить игру",
                                     font=("Abaddon Cyr", 18), command=lambda mode="r": self.saves_control(mode),
                                     foreground="#F00")
        self.button_selection(self.button_load)
        self.button_load.place(x=145, y=250)
        self.button_exit = tk.Button(img_win, width=14, height=2, bg="#311", activebackground="#844", text="Выход",
                                     font=("Abaddon Cyr", 18), command=self.destroy, foreground="#F00")
        self.button_selection(self.button_exit)
        self.button_exit.place(x=145, y=450)
        self.mainloop()

    def save_game(self, index, btn):
        saves = open(f"saves//save{index+1}.txt", "w")
        new_progress = (self.m * self.n - self.cells) / self.m * self.n
        saves.write("{:.1f}%\n".format(new_progress))
        saves.write(f"{self.flags}\n")
        saves.write(f"{self.m}\n")
        saves.write(f"{self.n}\n")
        saves.write(f"{self.cells}\n")
        for i in range(self.m):
            for j in range(self.n):
                if j < self.n - 1:
                    saves.write(f"{self.ground[i][j]}*{self.exploring[i][j]}=")
                else:
                    saves.write(f"{self.ground[i][j]}*{self.exploring[i][j]}")
            if i < self.m - 1:
                saves.write("~")
        btn.config(text=f"Ячейка {index + 1}: {new_progress}%", height=2)
        saves.close()

    def load_game(self, index):
        saves = open(f"saves//save{index + 1}.txt", "r")
        new_progress = saves.readline()
        self.flags = int(saves.readline())
        self.m = int(saves.readline())
        self.n = int(saves.readline())
        self.cells = int(saves.readline())
        s = [[[int(z) for z in y.split('*')] for y in x.split('=')] for x in saves.readline().split('~')]
        for i in range(self.m):
            for j in range(self.n):
                self.ground[i][j] = s[i][j][0]
                self.exploring[i][j] = s[i][j][1]
        saves.close()
        self.saves_win.withdraw()
        self.start_game()

    def win_moving(self, win, element):
        global xwin, ywin

        def move_window(event):
            global xwin, ywin
            win.geometry('+{0}+{1}'.format(event.x_root - xwin, event.y_root - ywin))

        def get_xy(event):
            global xwin, ywin
            xwin, ywin = pyautogui.position()
            xwin -= int(win.geometry().split('+')[1])
            ywin -= int(win.geometry().split('+')[2])

        element.bind('<B1-Motion>', move_window)
        element.bind('<Button-1>', get_xy)

    def button_selection(self, btn, color1="#311", color2="#000"):
        def change_on_hovering(event):
            btn['bg'] = color2

        def return_to_normalstate(event):
            btn['bg'] = color1

        btn.bind('<Enter>', change_on_hovering)
        btn.bind('<Leave>', return_to_normalstate)

    def saves_control(self, mode):
        pygame.mixer.Sound("button.mp3").play()
        for child in self.saves_win.winfo_children():
            child.destroy()
        global saves
        self.saves_win.deiconify()
        self.saves_win.geometry("250x300+250+300")
        self.win_moving(self.saves_win, self.saves_win)

        saves = []
        progress = []
        saves_buttons = []
        for i in range(3):
            saves.append(open(f"saves//save{i+1}.txt", "r+"))
            progress.append(saves[i].readline())
            saves_buttons.append(tk.Button(self.saves_win, width=15, font=("Abaddon Cyr", 18), bg="#311", foreground="#F00",
                                           activebackground="#844", text=f"Ячейка {i+1}: {progress[i]}"))
            self.button_selection(saves_buttons[i])
            if mode == 'w':
                saves_buttons[i].config(command=lambda index=i, btn=saves_buttons[i]: self.save_game(index, btn))
            else:
                if progress[i] == "0.0%\n":
                    saves_buttons[i].config(state="disabled")
                saves_buttons[i].config(command=lambda index=i: self.load_game(index))
            saves_buttons[i].pack()
            saves[i].close()
        btn_back = tk.Button(self.saves_win, width=15, anchor="center", font=("Abaddon Cyr", 18), bg="#311", activebackground="#844",
                             text="Назад", command=self.saves_win.withdraw, foreground="#F00")
        self.button_selection(btn_back)
        btn_back.pack(side="bottom")

    def defeat(self):
        defeat_win = tk.Toplevel(self)
        defeat_win.geometry("+500+500")
        defeat_win.overrideredirect(True)
        head_d = tk.Canvas(defeat_win, bg="#622", borderwidth=-2, relief="raised")
        head_d.pack(fill="x", side="top")
        self.win_moving(defeat_win, head_d)
        close_d = tk.Button(head_d, text=" X ", bg="#222", command=defeat_win.destroy,
                            foreground="white", relief="raised")
        close_d.pack(side="right")
        self.button_selection(close_d)
        can_d = tk.Label(defeat_win, image=self.pictures[21], borderwidth=-2)
        can_d.pack()
        pygame.mixer.Sound("smeshno.mp3").play()
        self.game_win.unbind("<ButtonPress-1>")
        self.game_win.unbind("<ButtonRelease-1>")
        for i in range(self.m):
            for j in range(self.n):
                if self.ground[i][j] == -1:
                    if self.exploring[i][j] == -3:
                        for child in self.field[i][j].winfo_children():
                            child.destroy()
                        tk.Label(self.field[i][j], image=self.pictures[20], borderwidth=-2,
                                 activebackground="#000", bg="#000").pack()
                    else:
                        tk.Label(self.field[i][j], image=self.pictures[19], borderwidth=-2,
                                 activebackground="#000", bg="#000").pack()
                        self.field[i][j].config(state="disabled")
                elif self.exploring[i][j] == -2:
                    for child in self.field[i][j].winfo_children():
                        child.destroy()
                    tk.Label(self.field[i][j], image=self.pictures[10], borderwidth=-2,
                             activebackground="#000", bg="#000").pack()
                    self.field[i][j].config(state="disabled")

    def victory(self):
        def next_stage():
            pygame.mixer.music.load("Dev.mp3")
            pygame.mixer.music.play(-1)
            victory_win.destroy()
        pygame.mixer.music.load("WIN.mp3")
        pygame.mixer.music.play(-1)
        victory_win = tk.Toplevel(self)
        victory_win.geometry("+500+500")
        victory_win.overrideredirect(True)
        head_v = tk.Canvas(victory_win, bg="#C5ABDB", borderwidth=-2, relief="raised")
        head_v.pack(fill="x", side="top")
        self.win_moving(victory_win, head_v)
        close_v = tk.Button(head_v, text=" X ", bg="#80A", command=next_stage,
                            foreground="white", relief="raised")
        close_v.pack(side="right")
        self.button_selection(close_v)
        can_v = tk.Label(victory_win, image=self.pictures[22], borderwidth=-2)
        can_v.pack()
        self.game_win.unbind("<ButtonPress-1>")
        self.game_win.unbind("<ButtonRelease-1>")
        for i in range(self.m):
            for j in range(self.n):
                if self.exploring[i][j] == -2:
                    tk.Label(self.field[i][j], image=self.pictures[10], borderwidth=-2,
                             activebackground="#000", bg="#000").grid()
                    self.field[i][j].config(state="disabled")

    def menu_btn(self):
        pygame.mixer.Sound("button.mp3").play()
        if self.state() == "withdrawn":
            self.deiconify()
        else:
            self.withdraw()

    def start_game(self):
        pygame.mixer.Sound("button.mp3").play()
        for child in self.game_win.winfo_children():
            child.destroy()
        self.withdraw()  # .deiconify()
        self.game_win.deiconify()
        self.game_win.geometry("+300+300")
        game_window = tk.Canvas(self.game_win, bg="#622", borderwidth=-2)
        game_window.pack(expand=1, fill="both")
        self.win_moving(self.game_win, game_window)
        flag_lbl = tk.Label(game_window, image=self.pictures[16], font="15", bg="#622",
                                activebackground="#844")
        flag_lbl.grid(rowspan=2, columnspan=2, row=0, column=0, sticky="nsew")
        flag_cnt = tk.Label(game_window, text=str(self.flags), font=("Abaddon Cyr", 18), bg="#622",
                             activebackground="#844", foreground="#313")
        flag_cnt.grid(rowspan=2, columnspan=2, row=0, column=2, sticky="nsew", padx=20)
        demon_face = tk.Label(game_window, image=self.pictures[13], bg="#622", borderwidth=-2,
                                 relief="sunken", activebackground="#844")
        demon_face.grid(rowspan=2, columnspan=3, row=0, column=self.n // 2 - 1, sticky="nsew", padx=30)
        self.win_moving(self.game_win, demon_face)
        save_button = tk.Button(game_window, image=self.pictures[17], font="15", bg="#622", width=70, height=70,
                                activebackground="#844", command=lambda mode="w": self.saves_control(mode))
        save_button.grid(rowspan=2, columnspan=2, row=0, column=self.n - 3, sticky="w", padx=[20, 0])
        menu_button = tk.Button(game_window, image=self.pictures[18], font="15", bg="#622",
                                activebackground="#844", command=self.menu_btn)
        menu_button.grid(rowspan=2, columnspan=2, row=0, column=self.n - 1, sticky="nsew")

        self.game_win.bind("<ButtonPress-1>", lambda t=0, img=self.pictures[14]: demon_face.config(image=img))
        self.game_win.bind("<ButtonRelease-1>", lambda t=0, img=self.pictures[13]: demon_face.config(image=img))

        shape = tk.Canvas(game_window, width=self.n * 48 + 2, height=self.m * 48 + 2, bg="#622", borderwidth=-2)
        shape.grid(rowspan=self.m, columnspan=self.n, row=2, column=0)
        self.field = [[tk.Button(shape, compound="center", bg="#FAA", image=self.pictures[10], borderwidth=-2,
                                 activebackground="#000") for y in range(self.n)] for x in range(self.m)]
        for i in range(self.m):
            for j in range(self.n):
                self.field[i][j].bind("<Button-3>",
                                      lambda event, index=[i, j], element=flag_cnt: self.flag(index, element))
                self.field[i][j].place(x=j*48, y=i*48)

        if self.ground[0][0] == -2:
            for i in range(self.m):
                for j in range(self.n):
                    self.field[i][j].config(command=lambda index=[i, j]: demine(index))
                    def demine(index):
                        safe_zone = {}
                        self.ground = [[0 for x in range(self.n)] for y in range(self.m)]
                        for i in range(self.m):
                            for j in range(self.n):
                                if ((i > index[0] + 1) or (i < index[0] - 1)) or (
                                        (j > index[1] + 1) or (j < index[1] - 1)):
                                    safe_zone[f"{i} {j}"] = f"{i} {j}"
                                    self.field[i][j].config(command=lambda index=[i, j]: self.step(index[0], index[1]))
                        for i in range(self.flags):
                            mine_key = random.choice(list(safe_zone.keys()))
                            del safe_zone[mine_key]
                            mine_index = [int(x) for x in mine_key.split()]
                            self.ground[mine_index[0]][mine_index[1]] = -1
                            for ii in range(mine_index[0] - 1, mine_index[0] + 2):
                                for jj in range(mine_index[1] - 1, mine_index[1] + 2):
                                    if (ii < self.m) and (jj < self.n) and (ii > -1) and (jj > -1) and (
                                            self.ground[ii][jj] != -1):
                                        self.ground[ii][jj] += 1
                        self.step(index[0], index[1])
        else:
            for i in range(self.m):
                for j in range(self.n):
                    self.field[i][j].config(command=lambda index=[i, j]: self.step(index[0], index[1]))
                    self.field[i][j].place(x=j * 48, y=i * 48)
                    if self.exploring[i][j] == -3:
                        m = tk.Label(self.field[i][j], image=self.pictures[11], borderwidth=0, bg="#000")
                        m.bind("<Button-3>", lambda event, index=(i, j), element=flag_cnt: self.flag(index, element))
                        m.pack()
                        self.field[i][j].config(state="disabled")
                    else:
                        if self.exploring[i][j] != -2:
                            self.field[i][j].config(bg="#AAA", relief="sunken", state="disabled")
                            self.field[i][j].unbind("<Button-3>")
                            lbl = tk.Label(self.field[i][j], image=self.pictures[self.ground[i][j]], borderwidth=-2,
                                           activebackground="#000", bg="#000")
                            lbl.bind("<Button-1>", lambda event, index=(i, j): self.auto_click(index[0], index[1]))
                            lbl.grid()
        flag_cnt["text"] = str(self.flags)

    def auto_click(self, x, y):
        c = 0

        for ii in range(x - 1, x + 2):
            for jj in range(y - 1, y + 2):
                if (ii < self.m) and (jj < self.n) and (ii > -1) and (jj > -1) and ((ii != x) or (jj != y)):
                    if self.exploring[ii][jj] == -3:
                        c += 1
        if c == self.ground[x][y]:
            for ii in range(x - 1, x + 2):
                for jj in range(y - 1, y + 2):
                    if (ii < self.m) and (jj < self.n) and (ii > -1) and (jj > -1) and ((ii != x) or (jj != y)):
                        if self.exploring[ii][jj] != -3:
                            self.step(ii, jj)

    def step(self, x, y):
        if self.ground[x][y] == -1:
            self.defeat()
        elif self.exploring[x][y] == -2:
            self.cells -= 1
            self.field[x][y].config(bg="#AAA", relief="sunken", state="disabled")
            self.field[x][y].unbind("<Button-3>")
            lbl = tk.Label(self.field[x][y], image=self.pictures[self.ground[x][y]], borderwidth=-2,
                     activebackground="#000", bg="#000")
            lbl.grid()
            lbl.bind("<Button-1>", lambda event, index=(x, y): self.auto_click(index[0], index[1]))
            # {self.ground[x][y]}
            if self.cells == 0:
                self.victory()
            if self.ground[x][y] == 0:
                self.exploring[x][y] = 0
                for ii in range(x - 1, x + 2):
                    for jj in range(y - 1, y + 2):
                        if (ii < self.m) and (jj < self.n) and (ii > -1) and (jj > -1) and ((ii != x) or (jj != y)):
                            self.step(ii, jj)
            else:
                self.exploring[x][y] = self.ground[x][y]

    def flag(self, index, element):
        if self.flags > 0:
            if self.exploring[index[0]][index[1]] != -3:
                sound = pygame.mixer.Sound("flag.mp3")
                sound.play()
                m = tk.Label(self.field[index[0]][index[1]], image=self.pictures[11], borderwidth=0, bg="#000")
                m.bind("<Button-3>", lambda event, index=(index[0], index[1]), element_=element: self.flag(index, element))
                m.pack()
                self.field[index[0]][index[1]].config(state="disabled")
                self.flags -= 1
                self.cells -= 1
                self.exploring[index[0]][index[1]] = -3
                if self.cells == 0:
                    self.victory()
            else:
                pygame.mixer.Sound("unflag.mp3").play()
                for child in self.field[index[0]][index[1]].winfo_children():
                    child.destroy()
                self.field[index[0]][index[1]].config(state="normal")
                self.flags += 1
                self.cells += 1
                self.exploring[index[0]][index[1]] = -2
        elif self.exploring[index[0]][index[1]] == -3:
            pygame.mixer.Sound("unflag.mp3").play()
            for child in self.field[index[0]][index[1]].winfo_children():
                child.destroy()
            self.field[index[0]][index[1]].config(state="normal")
            self.flags += 1
            self.cells += 1
            self.exploring[index[0]][index[1]] = -2
        element.config(text=str(self.flags))

    def trigger_in(self, index):
        self.field[index[0]][index[1]].config(bg="#F00")

    def trigger_out(self, index):
        self.field[index[0]][index[1]].config(bg="#0F0")

    def helper(self):
        self.game_win.withdraw()
        pygame.mixer.Sound("button.mp3").play()
        def next_stage():
            helper_w.destroy()
            self.report()
        helper_w = tk.Toplevel()
        helper_w.geometry("+300+300")
        helper_w.overrideredirect(True)
        helper_win = tk.Canvas(helper_w, bg="#522", borderwidth=5, relief="ridge")
        helper_win.pack(expand=1, fill="both")
        face = tk.Label(helper_win, image=self.pictures[23])
        comment = tk.Label(helper_win, font=("Abaddon Cyr", 14), bg="#644", borderwidth=3, relief="sunken", text="Демоны, которых вы держали в особой тюрьме\n и использовали для своих забав и экспери-\nментов, освободились от оков и пытаются \nвырваться на свободу. К счастью, выбраться \nиз подземелья им не под силу, только вы можете\n их изловить, ведь ваше шестое чувство \nподсказывает сколько нечистых находятся \nрядом с вами в радиусе одной клетки \n(но где они конкретно вам не ведомо). \nУ вас осталось мало магических клеток, \nровно столько сколько демонов в подземелье. \nДемонам хватит одного вашего промаха\n для освобождения. Будьте осторожны.")
        comment.pack(padx=20, pady=10)
        answer = tk.Button(helper_win, font=("Abaddon Cyr", 18), bg="#C7C", text="...Приступим   ", command=next_stage,
                           height=2)
        face.pack(side="left", padx=10, pady=10)
        answer.pack(side="left", expand=1, fill="both", padx=10, pady=10)
        self.win_moving(helper_w, helper_win)
        self.win_moving(helper_w, comment)

    def game_mode(self):
        self.m = 10
        self.n = 10
        self.cells = 100
        self.flags = 10
        self.ground = [[-2 for x in range(self.n)] for y in range(self.m)]
        self.exploring = [[-2 for x in range(self.n)] for y in range(self.m)]
        pygame.mixer.Sound("button.mp3").play()
        game_mode_root = tk.Toplevel()
        self.withdraw()
        game_mode_root.geometry("+300+300")
        game_mode_root.overrideredirect(True)
        game_mode_win = tk.Canvas(game_mode_root, bg="#422", borderwidth=-2)
        game_mode_win.pack(expand=1, fill="both")
        self.win_moving(game_mode_root, game_mode_win)
        btn_difficult = [tk.Button(game_mode_win, width=10, height=2, bg="#311", activebackground="#844",
                                   text=("EASY", "NORMAL", "HARD")[i],
                                   font=("Abaddon Cyr", 15), command=lambda index=i: mode_change(index),
                                   foreground="#F00") for i in range(3)]
        btn_size = [tk.Button(game_mode_win, width=10, height=2, bg="#311", activebackground="#844",
                                   text=("10x10", "15x20", "18x25")[i],
                                   font=("Abaddon Cyr", 15), command=lambda index=i: size_change(index),
                                   foreground="#F00") for i in range(3)]
        lbl1 = tk.Label(game_mode_win, width=10, height=2, bg="#622", activebackground="#844",
                        text="Сложность", font=("Abaddon Cyr", 15))
        lbl1.grid(row=1, column=0)
        lbl2 = tk.Label(game_mode_win, width=10, height=2, bg="#622", activebackground="#844",
                        text="Размер", font=("Abaddon Cyr", 15))
        lbl2.grid(row=3, column=0)

        for i in range(3):
            btn_difficult[i].grid(row=1, column=i+1)
            btn_size[i].grid(row=3, column=i+1)
            if i > 0:
                btn_difficult[i].config(bg="#111", foreground="#D00")
                self.button_selection(btn_difficult[i], "#111", "#000")
                btn_size[i].config(bg="#111", foreground="#D00")
                self.button_selection(btn_size[i], "#111", "#000")
            else:
                self.button_selection(btn_difficult[i])
                self.button_selection(btn_size[i])

        def mode_change(index):
            for i in range(3):
                if i != index:
                    btn_difficult[i].config(bg="#111", foreground="#D00")
                    self.button_selection(btn_difficult[i], "#111", "#000")
            btn_difficult[index].config(bg="#311", foreground="#F00")
            self.button_selection(btn_difficult[index])
            if index == 0:
                self.flags = int(self.m * self.n * 0.1)
            elif index == 1:
                self.flags = int(self.m * self.n * 0.16)
            else:
                self.flags = int(self.m * self.n * 0.2)

        def size_change(index):
            for i in range(3):
                if i != index:
                    btn_size[i].config(bg="#111", foreground="#D00")
                    self.button_selection(btn_size[i], "#111", "#000")
            btn_size[index].config(bg="#311", foreground="#F00")
            self.button_selection(btn_size[index])
            if index == 0:
                self.m = 10
                self.n = 10
            elif index == 1:
                self.m = 15
                self.n = 20
            else:
                self.m = 18
                self.n = 25
            self.cells = self.m*self.n
            self.ground = [[-2 for x in range(self.n)] for y in range(self.m)]
            self.exploring = [[-2 for x in range(self.n)] for y in range(self.m)]
            for i in range(3):
                if btn_difficult[i].cget("bg") == "#311":
                    mode_change(i)


        def next_stage():
            game_mode_root.destroy()
            self.helper()

        btn_close = tk.Button(game_mode_win, height=2, bg="#311", activebackground="#844", width=40,
                                   text="Готово!", font=("Abaddon Cyr", 15), foreground="#F00", command=next_stage)
        self.button_selection(btn_close)
        btn_close.grid(row=5, column=0, columnspan=4)

    def report(self):
        pygame.mixer.Sound("button.mp3").play()
        for child in self.game_win.winfo_children():
            child.destroy()
        self.game_win.deiconify()
        self.game_win.geometry("+300+100")
        game_window = tk.Canvas(self.game_win, bg="#622", borderwidth=-2)
        game_window.pack(expand=1, fill="both")
        self.win_moving(self.game_win, game_window)
        flag_lbl = tk.Label(game_window, image=self.pictures[16], font="15", bg="#622",
                            activebackground="#844")
        flag_lbl.grid(rowspan=2, columnspan=2, row=0, column=0, sticky="nsew")
        flag_cnt = tk.Label(game_window, text=str(self.flags), font=("Abaddon Cyr", 18), bg="#622",
                            activebackground="#844", foreground="#313")
        flag_cnt.grid(rowspan=2, columnspan=2, row=0, column=2, sticky="nsew", padx=20)
        demon_face = tk.Label(game_window, image=self.pictures[13], bg="#622", borderwidth=-2,
                              relief="sunken", activebackground="#844")
        demon_face.grid(rowspan=2, columnspan=3, row=0, column=self.n // 2 - 1, sticky="nsew", padx=30)
        self.win_moving(self.game_win, demon_face)
        save_button = tk.Button(game_window, image=self.pictures[17], font="15", bg="#622", width=70, height=70,
                                activebackground="#844", command=lambda: msg.showinfo("Внимание", "Начните игру, прежде чем сохраняться"))
        save_button.grid(rowspan=2, columnspan=2, row=0, column=self.n - 3, sticky="w", padx=[20, 0])
        menu_button = tk.Button(game_window, image=self.pictures[18], font="15", bg="#622",
                                activebackground="#844", command=self.menu_btn)
        menu_button.grid(rowspan=2, columnspan=2, row=0, column=self.n - 1, sticky="nsew")

        self.game_win.bind("<ButtonPress-1>", lambda t=0, img=self.pictures[14]: demon_face.config(image=img))
        self.game_win.bind("<ButtonRelease-1>", lambda t=0, img=self.pictures[13]: demon_face.config(image=img))

        shape = tk.Canvas(game_window, width=self.n * 48 + 2, height=self.m * 48 + 2, bg="#622", borderwidth=-2)
        shape.grid(rowspan=self.m, columnspan=self.n, row=2, column=0)
        self.field = [[tk.Button(shape, compound="center", bg="#FAA", image=self.pictures[10], borderwidth=-2,
                                 activebackground="#000",
                                 command=lambda index=[x, y]: demine(index)) for y in range(self.n)] for x in range(self.m)]
        for i in range(self.m):
            for j in range(self.n):
                self.field[i][j].bind("<Button-3>",
                                      lambda event, index=[i, j], element=flag_cnt: self.flag(index, element))
                self.field[i][j].place(x=j * 48, y=i * 48)

        def demine(index):
            save_button.config(command=lambda mode="w": self.saves_control(mode))
            safe_zone = {}
            self.ground = [[0 for x in range(self.n)] for y in range(self.m)]
            for i in range(self.m):
                for j in range(self.n):
                    if ((i > index[0] + 1) or (i < index[0] - 1)) or ((j > index[1] + 1) or (j < index[1] - 1)):
                        safe_zone[f"{i} {j}"] = f"{i} {j}"
                        self.field[i][j].config(command=lambda index=[i, j]: self.step(index[0], index[1]))
            for i in range(self.flags):
                mine_key = random.choice(list(safe_zone.keys()))
                del safe_zone[mine_key]
                mine_index = [int(x) for x in mine_key.split()]
                self.ground[mine_index[0]][mine_index[1]] = -1
                for ii in range(mine_index[0] - 1, mine_index[0] + 2):
                    for jj in range(mine_index[1] - 1, mine_index[1] + 2):
                        if (ii < self.m) and (jj < self.n) and (ii > -1) and (jj > -1) and (self.ground[ii][jj] != -1):
                            self.ground[ii][jj] += 1
            self.step(index[0], index[1])

if __name__ == "__main__":
    Minesweeper()
